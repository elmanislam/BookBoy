from colorama import Fore, Back, Style

text = input("Enter your text here\n")

print(Fore.RED + text + Style.RESET_ALL)
print(Style.BRIGHT + text)
print(Fore.CYAN + text + Style.RESET_ALL)