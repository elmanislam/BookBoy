picture = "exploding_baby_trump.png"

from PIL import Image

img = Image.open(picture)
img.show()
