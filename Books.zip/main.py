#Main log

# date of creation: August 20, 2021
# Author: Elman Islam
# last updated: September 1, 2021
#This program has been built entirely by Elman Islam for recreational purposes, and is free to be used by anyone. Authorization to use google's Book API is not required.

import repl
import csv
import os

from colorama import Fore, Back, Style
from search_query import *

def add_book(author, title, year, status, date_added):
  if not os.path.exists(f'books/{title}'):
    os.makedirs(f'books/{title}')
  else:
    print(f'Line 17 - {title} already exists as an entry. returning to menu.\n\n')
    return
  with open('book_entries.csv', mode='a') as books_file:
      books_writer = csv.writer(books_file, delimiter=',', quotechar='"', quoting=csv.QUOTE_MINIMAL)

      books_writer.writerow([author, title, year, status.upper()])
  
  books_file.close()

def choice_2():
  with open('book_entries.csv') as books_file:
    csv_reader = csv.reader(books_file, delimiter=',')
    line_count = 0
    for row in csv_reader:
        if line_count == 0:
            print(f'Column names are {", ".join(row)}')
            line_count += 1
        else:
            print(f'\n\t{row[1]} ({row[2]}), by {row[0]} ')
            line_count += 1
    print(f'\nProcessed {line_count} lines.')
  books_file.close()

def choice_3():
  print("select filter\n1. By Author\n2. By Title")
  filter = int(input())

  if filter > 2 or filter < 1:
    print("line 44 - input not recognized. Returning to menu.")
  
  name = input("enter name: ").lower()

  with open('book_entries.csv') as books_file:
    csv_reader = csv.reader(books_file, delimiter=',')
    line_count = 0
    for row in csv_reader:
      if line_count > 0:
        if (row[filter - 1].lower()).find(name) != -1:
          print(f'{row[filter - 1]} - {row[3 - (filter + 1)]}, published on {row[2]}')
      line_count +=1
  
  books_file.close()




def choice_1():
  title = input("enter title: ")
  author = input("enter author: ")
  year = input("enter year of publication: ")
  status = input("Finished reading? (Y/N)")

  while status != 'Y' and status != 'N' and status != 'y' and status != "n":
    print("Line 46 - Character not recognized.")
    status = input("Finished reading? (Y/N)")
  
  if status == "Y" or status == "y":
    date_added = input("enter month that you finished the book (1-12)")
  

  add_book(author, title, year, status, date_added)

#def sort_books():

#excecutes the Main Menu
def main():
  while True:
    print(
      Fore.GREEN + " -----MAIN MENU-----\n"
      "1. enter book title\n"
      "2. display books read\n"
      "3. search for entry\n"
      "4. sort entries (unavailable, currently under construction)\n"
      "5. browse book titles and download entries on google books\n" + Style.RESET_ALL)
    answer = input()
    if answer == '1':
      choice_1()


    elif answer == '2':
      choice_2()
      input("\n\n   ***enter any key to continue***\n")
    elif answer == '3':
      choice_3()
      input("\n   ***enter any key to continue***\n")
    elif answer == '5':
      choice_5()
      input("\n\n   ***enter any key to continue***\n")
    else:
      print("closing program\n")
      break
      quit()

main()