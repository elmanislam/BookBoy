from colorama import Fore, Back, Style


# Python's built-in module for encoding and decoding JSON data
api = "https://www.googleapis.com/books/v1/volumes?q="
import json

# Python's built-in module for opening and reading URLs
from urllib.request import urlopen

#checks if a category is missing in volume_info [see comment on Line 47]
def error_check(category, name, volume_info):
  try:
    print(Fore.BLUE + f"{name}: {volume_info[category]}")
  except KeyError:
    print(Fore.RED + f"{name}: Unavailable" + Style.RESET_ALL)

#checks how many search results have been found. It would seem that the maximum capacity is always 10
def item_count(user_input):
  resp = urlopen(api + user_input)
  book_data = json.load(resp)

  i = 0
  while i <= 20:
    if i + 1 == 21:
      print(f"{i} items have been found in the query (Maximum capability)")
    try:
      volume_info = book_data["items"][i]["volumeInfo"]
    except IndexError:
      print(f"{i} items have been found in the query")
      break
    i += 1

#retrieves information from book and prints it on screen
def retrieve_books(i, user_input):
  # send a request and get a JSON response
  resp = urlopen(api + user_input)
  # parse JSON into Python as a dictionary
  book_data = json.load(resp)

  # create additional variables for easy querying


  volume_info = book_data["items"][i]["volumeInfo"]
  author = volume_info["authors"]
  # practice with conditional expressions!
  prettify_author = author if len(author) > 1 else author[0]
  
  # display title, author, page count, publication date
  # fstrings require Python 3.6 or higher
  # \n adds a new line for easier reading

  print(f"\n*** SEARCH RESULT {i + 1} ***\n")
  #error_check(volume_info['selfLink'], "Self Link")
  error_check('title', "Title", volume_info)
  #error_check(prettify_author, "Author", volume_info)
  error_check('pageCount', "Page count", volume_info)
  error_check('publishedDate', "Publication Date", volume_info)
  error_check('description', "Description", volume_info)

def choice_5():
   
  #filter allows for filtering search results
  filter = int(input("\nSearch by:\n1. All\n2. Title\n3. Author\n4. ISBN\n5.Custom search\n"))

  if filter == 1:
    user_input = input("Enter name: ").replace(" ", "+").strip()
  elif filter == 2:
    user_input = "intitle:" + input("Enter name of title: ").replace(" ", "+").strip()
  elif filter == 3:
    user_input = "inauthor:" + input("Enter name of author: ").replace(" ", "+").strip()
  elif filter == 4:
    user_input = "isbn:" + input("Enter 10 digit ISBN: ").replace(" ", "+").strip()
  elif filter == 5:
    user_input = input("Enter custom input: ").replace(" ", "+").strip()
  else:
    print("line 28 - input not recognized. Returning to menu.")
    return

  user_update = input("check query count? (Y/N) ").lower().strip()
  if user_update == "y":
    item_count(user_input)

  num_results = int(input("Enter number of results to be displayed (MAX - [20]): "))
  if num_results <= 0 or num_results > 20:
    print("Line 33 - invalid number response. Returning to menu.\n")
    return
  for i in range(0, num_results):
    retrieve_books(i, user_input)
  
  user_update = input("\nSee next search result? (Y/N) ").lower().strip()
  while user_update == "y":
    i += 1
    retrieve_books(i, user_input)
    user_update = input("\nSee next search result? (Y/N) ").lower().strip()

  user_choice = int(input("Select an entry to download by entering its respective number. Press 0 to quit this function. \n"))
  if user_choice > 0 and user_choice <= i + 1:
    retrieve_books(user_choice - 1, user_input)



'''
  # ask user if they would like to search for another entry
  user_update = input("Would you like to search again? (Y/N) ").lower().strip()

  if user_update != "y" and user_update != "Y":
      print("May the Zen of Python be with you. Have a nice day!")
      break # as the name suggests, the break statement breaks out of the while loop


try:
    from googlesearch import search
except ImportError: 
    print("No module named 'google' found")
  
# to search
query = input("search something on google: ")
  
for j in search(query, tld="co.in", num=10, stop=10, pause=2):
    print(j)
'''


